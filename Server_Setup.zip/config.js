export const API_URL = window.location.hostname === "localhost" ? "<add your theia server side url>" : "add your theia server side url";
console.log(
    "API_URL :",
    API_URL
);